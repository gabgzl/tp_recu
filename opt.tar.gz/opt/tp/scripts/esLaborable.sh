#!/bin/bash
#Funcion para determinar si una fecha es dia laborable o no 
esLaborable() {
	if [ -z "$1" ]; then
		echo "Deben proporcionar una fecha en formato 'YYYY-MM-DD' como aargumento"
		return 1
	fi
	#aqui se proporciona la fecha como argumento
	fecha="$1"
	#verifico si la fecha es un dia de la semana
	case "$fecha" in
		"2023-01-01" | "2023-03-24" | "2023-04-02" | "2023-04-02" | "2023-05-01" | "2023-05-25" | "2023-06-20" | "2023-07-09" | "2023-08-17" | "2023-10-12" | "2023-11-20" | "2023-12-08" | "2023-12-25")
		echo "La fecha $fecha es un dia NO laborable"
		return 0
		;;
	esac
	jueves_santo=$(date -d "$fecha -1 day" "+%m-%d")
	if [ "$jueves_santo" == "03-24" ]; then
		echo "La fecha $fecha es un dia no laborable porque es jueves santo"
		return 0
	fi
	if [ $(date -d "$fecha" "+%u") -le 5 ]; then
		echo "La fecha $fecha es un dia laborable"
	else
		echo "La fecha $fecha no es un dia laborable"
	fi
}
if [ -n "$1" ]; then
	esLaborable "$1"
fi

